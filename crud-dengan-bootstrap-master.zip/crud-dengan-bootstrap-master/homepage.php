<?php
session_start();
if(!isset($_SESSION["stat_login"]) and
	!isset($_SESSION["username"]) and
	!isset($_SESSION["password"]))
{
	die("anda belum login, silahkan klik
	<a href='Index.php'>di sini</a>untuk login");
}
else
{
echo		"<p>
			Login berhasil, Selamat Datang
			".$_SESSION["username"].
			"</p>";
		echo "<p><a href='logout.php'>Logout</a></p>";
}
?>