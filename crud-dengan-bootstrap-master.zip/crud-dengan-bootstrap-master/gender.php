<?php
$gender = $_GET ["gender"];
echo "Kamu adalah seorang $gender"
?>