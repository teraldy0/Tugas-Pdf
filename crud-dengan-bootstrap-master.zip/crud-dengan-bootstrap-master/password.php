<?php
$password = $_GET ["pass"];
echo "Password kamu adalah $password"
?>