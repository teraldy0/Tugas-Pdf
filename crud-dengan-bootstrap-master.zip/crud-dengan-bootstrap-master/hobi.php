<?php
$hobi = $_GET ["hobi"];
echo "Kamu telah memilih $hobi."
?>