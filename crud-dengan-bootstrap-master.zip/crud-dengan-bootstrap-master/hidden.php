<?php
$password = $_GET ["password"];
echo "Text hidden itu adalah $password"
?>