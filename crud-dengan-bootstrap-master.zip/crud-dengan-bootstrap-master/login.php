<html>
<head>
<title> Login </title>
</head>
<center>
<tr height="10px">
	<div class="center" style="width:300px; height:300px;">
</div>
	<th><table border="2" >
	<tr>
	<th><h1>LOGIN BRO</h1></th>
	</table>
	</tr>
	</th>
<body bgcolor="white">
<?php
include('index.php');
echo" <form action='validasi.php' method='post'>
		<p>Username :<br>
		<input type='text' name='username'/></p>
		<p>Password :<br>
		<input type='password' name='password'/></p>
		<p><button type='submit'>Login</button></p>
		</form>";
?>
<tr>
	<td><h1> Good Luck with your account... no one account is safe !! </h1></td>