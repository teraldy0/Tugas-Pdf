<?php
$textarea = $_POST ["textarea"];
echo "Alamat kamu di $textarea"
?>